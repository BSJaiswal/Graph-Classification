#!/usr/bin/env python

tp= open('poutput2', 'r')
tn= open('noutput3', 'r')
t= open('test.txt', 'w+')
sp = tp.readline()
counterp=0
countern=0
while (len(sp)>1 and counterp < 100000):
    t.write(sp[2:])
    sp = tp.readline()
    counterp +=1
    if sp == "":
        break
sn = tn.readline()
while (len(sn)>1 and countern < 100000):
    t.write(sn[3:])
    sn = tn.readline()
    countern +=1
    if sn == "":
        break
tp.close()
tn.close()
t.close()	
