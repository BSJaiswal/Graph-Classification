#!/usr/bin/env python
# coding: utf-8

# In[3]:


#!/usr/bin/env python

#smodule for label List
a= open('equal.lab', 'r') # two lists a queries b and b in turn queries c; than a-c tuple will define feature vector

A1 = []
A0 = []
z = a.read(1)

counterA = 0
while ((z in ['0','1']) and (counterA < 1000000)):
    if (z == '1'):
        a.read(1)
        z1=a.readline().strip()
        A1.append(z1)
    else:
        a.read(1)
        z0=a.readline().strip()
        A0.append(z0)
    counterA += 1
    z = a.read(1)
# print(A1)
# print(A0)
# print(len(A1))
# print(len(A0))
a.close()

#"smodule for Dictionary from data.txt"
b= open('data.txt', 'r') # two lists a queries b and b in turn queriws c; than a-c tuple will define feature vector

Bdict= { }
y1 = b.read(1)

counterB = 0
while ((y1 == 'c') and (counterB < 1000000)):
    b.read(1)
    y2=b.read(1)

    if (y2 == '#'):
        b.read(1)
        y3=b.readline()
        yLb=y3.split()
        Bdict.update({yLb[0]: yLb[1]})
        counterB += 1
    y1 = b.read(1)
    while (y1 != 'c'):
        y0=b.readline()
        if y0 == "":
            break
        y1 = b.read(1)
# print(Bdict)
# t= open('t.txt', "w")
# for key in Bdict:
#     t.write(key + ':' + Bdict[key]+ ' ')
# t.close()
b.close()

#"smodule for finding Dictionary for data.txt"
c= open('fsubgraph.txt', 'r')

Cdict= { }
x1 = c.read(1)
if x1==' ':
    c.readline()
x1 = c.read(1)
counterC = 0
while ((x1 == 't') and (counterC < 100)):
    c.read(1)
    x2=c.read(1)
    # print(x2)
    if (x2 == '#'):
        c.read(1)
        x3=c.readline()
        xL1c=x3.split()
        # print(xL1c)
        x1 = c.read(1)
        while (x1 in ['e','v']):
            x0=c.readline()
            x1 = c.read(1)
        if x1==' ':
            x1 = c.read(1)
        if x1=='{':
            x4=c.readline().strip()
        xL2c=x4.split()
        temp=(int(xL1c[2])-1)
#         print(temp)
        tempID= str(xL2c[temp])
#         print(tempID)
#             tempID.strip
        lastID=tempID.strip('}')
#         xL2c[last].strip()
        graphIDS = set()
#             print(l)
        for i in range (0,temp):
            graphIDS.add(xL2c[i])
#             print(graphIDS)
            graphIDS.add(lastID)
#         print(graphIDS)
        c.readline()
        x1 = c.read(1)
#         print(x1)
    Cdict.update({xL1c[0]: graphIDS})
#     print(Cdict)
    counterC += 1
#     print(counterC)
    if x1 == "":
        break            
#           
# print(Cdict)
DSgraphSize = len(Cdict)
# print(Cdict['1'])
# print(DSgraphSize)
c.close()

#"smodule for finding feature vector"
dictFVp={}
dictFVn={}
for graphID in A1:
    y1 = Bdict.get(graphID)
#     print(y1)
    if y1 != None:
        value = []
        fdict= {}
#         print('ok')
        for j in range (0, DSgraphSize):
#             print(DSgraphSize)
            s= str(j)
#             print(j)
            sdict= Cdict[s]
#             print(sdict)
            st= str(y1)
#             print(st)
            if st in sdict:
                value.append('1')
            else:
                value.append('-1')
            fdict.update({j: value[j]})
	dictFVp.update({y1: fdict})
# print(dictFVp)

for graphID in A0:
    y0 = Bdict.get(graphID)
#     print(y1)
    if y0 != None:
        value = []
        fdict= {}
#         print('ok')
        for j in range (0, DSgraphSize):
#             print(DSgraphSize)
            s= str(j)
#             print(j)
            sdict= Cdict[s]
#             print(sdict)
            st= str(y0)
#             print(st)
            if st in sdict:
                value.append('1')
            else:
                value.append('-1')
            fdict.update({j: value[j]})
    dictFVn.update({y0: fdict})
plength= len(dictFVn)
# print(dictFVn)

#"smodule for writing positive feature vectors in file"
p= open('pvector.txt', "w")
for pkey in dictFVp:
    pdict= dictFVp[pkey]
    p.write('1 ')
    for v in pdict:
        p.write(str(v) + ':' + pdict[v]+ ' ')
    p.write('\n')
p.close()

#"module for writing negative feature vectors in file"
n= open('nvector.txt', "w")
for nkey in dictFVn:
    ndict= dictFVn[nkey]
    n.write('-1 ')
    for v in ndict:
        n.write(str(v) + ':' + ndict[v]+ ' ')
    n.write('\n')
n.close()


# In[ ]:




