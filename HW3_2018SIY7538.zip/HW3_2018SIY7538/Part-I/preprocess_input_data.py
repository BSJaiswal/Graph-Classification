#!/usr/bin/env python
# coding: utf-8
# python script for preprocessing input data for gspan and gaston
# for pafi the e in the output is to be replaced by u by using 'find and replace' feature in the text file
h= open('atom.txt', 'r')
u = h.read().splitlines()
atomID=0
dictatom = {}
for atom in u:
    dictatom.update({atom : atomID})
    atomID = atomID+1
h.close()
f = open('aido99_all.txt', 'r')
g = open('preprocessed_input_data_e_for gspan_gaston.txt', 'w+')
s = f.readline().strip()
counter = 0
while (len(s)>1 and counter < 100000):
    g.write('t '+'#'+' '+ s[1:]+'\n')
    vt = f.readline().strip()
    y = int(vt)
    for i in range (0,y):
        z = f.readline().strip()
        y = dictatom[z]
        g.write('v '+ str(i) +' ' + str(y)+'\n')
    ez = f.readline().strip()
    k = int(ez)
    for j in range (0,k):
        m = f.readline().strip()
        g.write('e '+ str(m)+'\n')
    s = f.readline().strip()
    counter +=1
f.close()
g.close()
