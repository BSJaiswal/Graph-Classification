#!/usr/bin/env python
# coding: utf-8

h= open('atom.txt', 'r')
u = h.read().splitlines()
atomID=0
dictatom = {}
for atom in u:
    dictatom.update({atom : atomID})
    atomID = atomID+1
h.close()
f = open('final_trainset_1', 'r')
g = open('data.txt', 'w+')
s = f.readline().strip()
counter = 0
while (len(s)>1 and counter < 100000):
    g.write('c '+'#'+' '+ s[1:]+' '+ str(counter) +'\n')
    g.write('t '+'#'+' '+ s[1:]+'\n')
    vt = f.readline().strip()
    y = int(vt)
    for i in range (0,y):
        z = f.readline().strip()
        y = dictatom[z]
        g.write('v '+ str(i) +' ' + str(y)+'\n')
    ez = f.readline().strip()
    k = int(ez)
    for j in range (0,k):
        m = f.readline().strip()
        g.write('e '+ str(m)+'\n')
    s = f.readline().strip()
    counter +=1
kfile = open('value.txt', 'w+')
kfile.write(str(counter))
kfile.close()
f.close()
g.close()
